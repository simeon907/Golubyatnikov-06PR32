#ifndef GETEDITIONADM_H
#define GETEDITIONADM_H

#include <QMainWindow>
#include <QVector>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlDatabase>
#include "edition.h"
#include "paidedition.h"

namespace Ui {
class GetEditionAdm;
}

class GetEditionAdm : public QMainWindow
{
    Q_OBJECT

public:
    explicit GetEditionAdm(QWidget *parent = nullptr);
    ~GetEditionAdm();

private slots:
    void on_get_clicked();
    void load();
    //void getData(QString text);
    void on_type_activated(const QString &arg1);

    void on_pushButton_clicked();

    void on_id_activated(const QString &arg1);

private:
    Ui::GetEditionAdm *ui;
    QVector<Edition*> editions;
    QSqlDatabase db;
};

#endif // GETEDITIONADM_H
