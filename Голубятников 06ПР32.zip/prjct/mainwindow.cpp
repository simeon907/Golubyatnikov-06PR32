#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    adm = new AdminWindow();
      usr = new UserWindow();
      ui->user->hide();
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_admin_clicked()
{
    adm->show();
    this->hide();
}


void MainWindow::on_user_clicked()
{

}

