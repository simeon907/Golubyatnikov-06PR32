#include "addwindow.h"
#include "ui_addwindow.h"
#include <QFile>
#include <QTextStream>
#include <QVariant>
#include <QDebug>

addWindow::addWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::addWindow)
{
    ui->setupUi(this);
}

addWindow::~addWindow()
{
    delete ui;
}

void addWindow::on_pushButton_clicked()
{

    QSqlDatabase db = QSqlDatabase::addDatabase("QODBC");

    QString connectString = "Driver={SQL Server};";
    connectString.append("Server=SIMEON-DESKTOP;");
    connectString.append("Database=EDITIONS;");
    db.setDatabaseName(connectString);

    if(db.open())
    {
        ui->statusbar->showMessage("connect");
        QSqlQuery query;
        string kind = ui->kind->text().toStdString();
        string title = ui->title->text().toStdString();
        string author = ui->author->text().toStdString();
        QString date = ui->date->text();
        QStringList dList = date.split('.');
        QString d ="";
        d+=dList.at(2)+'-'+dList.at(1)+'-'+dList.at(0);
        int pages = ui->pages->text().toInt();
        bool rent = 0;
        string namerent = "";
        double price = ui->price->text().toDouble();
        if(!kind.empty() && !title.empty() && !author.empty())
        {
            if(price == 0)
            {
                query.prepare("insert into edition(kind, title, author, date_, pages, rent, name_rent)"
                        "values(:kind, :title, :author, :date, :pages, :rent, :namerent)");
                query.bindValue(":kind", kind.c_str());
                query.bindValue(":title", title.c_str());
                query.bindValue(":author", author.c_str());
                query.bindValue(":date", d);
                query.bindValue(":pages", pages);
                query.bindValue(":rent", rent);
                query.bindValue(":namerent", namerent.c_str());
                query.exec();
//                QString pgs = QString::fromStdString(to_string(pages));
//                QString nmrnt = QString::fromStdString(namerent);
//                emit sendData(QString::fromStdString(kind) +"="+ title.c_str()+"="+author.c_str()+"="+date+"="+pgs+"=0="+nmrnt);
            }
            else
            {
                query.prepare("insert into paid_edition(kind, title, author, date_, pages, rent, name_rent, price)"
                        "values(:kind, :title, :author, :date, :pages, :rent, :namerent, :price)");
                query.bindValue(":kind", kind.c_str());
                query.bindValue(":title", title.c_str());
                query.bindValue(":author", author.c_str());
                query.bindValue(":date", d);
                query.bindValue(":pages", pages);
                query.bindValue(":rent", rent);
                query.bindValue(":namerent", namerent.c_str());
                query.bindValue(":price", price);
                query.exec();
            }

        }
    }
    else
    {
        ui->statusbar->showMessage("error connect");
    }
}

