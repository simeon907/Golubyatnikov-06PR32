#ifndef DELWINDOW_H
#define DELWINDOW_H

#include <QMainWindow>
#include "edition.h"
#include "paidedition.h"
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlDatabase>

namespace Ui {
class delWindow;
}

class delWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit delWindow(QWidget *parent = nullptr);
    ~delWindow();

private slots:
    void on_delete_2_clicked();

private:
    Ui::delWindow *ui;
     QSqlDatabase db;
};

#endif // DELWINDOW_H
