#ifndef ADMINWINDOW_H
#define ADMINWINDOW_H

#include <QMainWindow>
#include "addwindow.h"
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlDatabase>
#include "edition.h"
#include "paidedition.h"
#include <QVector>
#include <string>
#include "delwindow.h"
#include "geteditionadm.h"
#include "returnedition.h"
using namespace std;

namespace Ui {
class AdminWindow;
}

class AdminWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit AdminWindow(QWidget *parent = nullptr);
    ~AdminWindow();
    void load();
    void showListToTableWidget();

private slots:
    void on_addButton_clicked();
    void on_delButton_clicked();
    void on_update_clicked();

    void on_get_clicked();

    void on_returnEd_clicked();

private:
   Ui::AdminWindow *ui;
   addWindow* addwin;
   delWindow* delwin;
   QVector<Edition*> editions;
   QSqlDatabase db;
   GetEditionAdm* gea;
   ReturnEdition*re;
};

#endif // ADMINWINDOW_H
