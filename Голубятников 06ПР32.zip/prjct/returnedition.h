#ifndef RETURNEDITION_H
#define RETURNEDITION_H

#include <QMainWindow>
#include <QVector>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlDatabase>
#include "edition.h"
#include "paidedition.h"

namespace Ui {
class ReturnEdition;
}

class ReturnEdition : public QMainWindow
{
    Q_OBJECT

public:
    explicit ReturnEdition(QWidget *parent = nullptr);
    ~ReturnEdition();

private slots:
    void on_get_clicked();
    void load();
    void on_pushButton_clicked();
    void on_type_activated(const QString &arg1);

private:
    Ui::ReturnEdition *ui;
    QVector<Edition*> editions;
    QSqlDatabase db;

};

#endif // RETURNEDITION_H
