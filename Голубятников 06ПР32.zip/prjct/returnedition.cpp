#include "returnedition.h"
#include "ui_returnedition.h"
#include <QDebug>
#include <QMessageBox>

ReturnEdition::ReturnEdition(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::ReturnEdition)
{
    ui->setupUi(this);
    ui->type->addItem("edition");
    ui->type->addItem("paid_edition");

    db = QSqlDatabase::addDatabase("QODBC");

    QString connectString = "Driver={SQL Server};";
    connectString.append("Server=SIMEON-DESKTOP;");
    connectString.append("Database=EDITIONS;");
    db.setDatabaseName(connectString);

    if(db.open())
    {
        ui->statusbar->showMessage("Connect");
        load();
        for(int i = 0;i<editions.size();i++)
        {
            if(editions[i]->getType()=="free" && editions[i]->getRent() && editions[i]->getNameRent()=="admin")
            {
                string str = to_string(editions[i]->getId());
                ui->id->addItem(str.c_str());
            }
        }
    }
    else
        ui->statusbar->showMessage("error connect");
}

ReturnEdition::~ReturnEdition()
{
    delete ui;
    db.close();
}

void ReturnEdition::on_get_clicked()
{
    QString selectedId = ui->id->itemText(ui->id->currentIndex());

    QSqlQuery query;
    QString type = ui->type->itemText(ui->type->currentIndex());
    qDebug()<<selectedId<<"|"<<type;
    QString q = "update "+type+" set rent = 0, name_rent = '' where id ="+selectedId;
    query.exec("select * from "+type+" where id = "+selectedId);
    query.first();
    qDebug()<<q;
    qDebug()<<query.value(6).toBool();
    if(query.value(6).toBool())
        query.exec(q);
    else
        QMessageBox::warning(this, "Error", "this edition has been rented");
    ui->statusbar->showMessage("updated");
}

void ReturnEdition::load()
{
    QSqlQuery query;
    query.exec("SELECT * FROM EDITION");

    while (query.next())
    {
       string kind = query.value(1).toString().toStdString();
       string title = query.value(2).toString().toStdString();
       string author = query.value(3).toString().toStdString();
       QString date = query.value(4).toString();
       QStringList datelist = date.split('-');
       Date d(datelist.at(0).toInt(), datelist.at(1).toInt(), datelist.at(2).toInt());
       int pages = query.value(5).toInt();
       bool rent = query.value(6).toBool();
       string nameRent = query.value(7).toString().toStdString();
       int id = query.value(0).toInt();
       editions.push_back(new Edition(kind, title, author, d, pages, rent, nameRent, id));
    }

    query.exec("SELECT * FROM paid_edition");

    while (query.next())
    {
       string kind = query.value(1).toString().toStdString();
       string title = query.value(2).toString().toStdString();
       string author = query.value(3).toString().toStdString();
       QString date = query.value(4).toString();
       QStringList datelist = date.split('-');
       Date d(datelist.at(0).toInt(), datelist.at(1).toInt(), datelist.at(2).toInt());
       int pages = query.value(5).toInt();
       bool rent = query.value(6).toBool();
       string nameRent = query.value(7).toString().toStdString();
       float price = query.value(8).toFloat();
       int id = query.value(0).toInt();
       editions.push_back(new PaidEdition(kind, title, author, d, pages, rent, nameRent, id, price));
    }
}


void ReturnEdition::on_type_activated(const QString &arg1)
{
    ui->id->clear();
    editions.clear();
    QString type = ui->type->itemText(ui->type->currentIndex());
    load();
    for(int i = 0;i<editions.size();i++)
    {
        if(type == "edition" && editions[i]->getType()=="free" && editions[i]->getRent() && editions[i]->getNameRent()=="admin")
        {
            string str = to_string(editions[i]->getId());
            ui->id->addItem(str.c_str());
        }
        else if(type =="paid_edition" && editions[i]->getType()=="paid" && editions[i]->getRent() && editions[i]->getNameRent()=="admin")
        {
            string str = to_string(editions[i]->getId());
            ui->id->addItem(str.c_str());
        }
    }
}

//void GetEditionAdm::getData(QString text)
//{
//    QStringList list=text.split("=");
//    editions.push_back(list.at(0))
//}


void ReturnEdition::on_pushButton_clicked()
{
    ui->statusbar->showMessage("updating...");
    db.close();
    db = QSqlDatabase::addDatabase("QODBC");
   QString connectString = "Driver={SQL Server};";
   connectString.append("Server=SIMEON-DESKTOP;");
   connectString.append("Database=EDITIONS;");
   db.setDatabaseName(connectString);

   if(db.open())
   {
       ui->statusbar->showMessage("updated");
       editions.clear();
       load();
       ui->id->clear();
       ui->type->clear();
       ui->type->addItem("edition");
       ui->type->addItem("paid_edition");

       for(int i = 0;i<editions.size();i++)
       {
           if(editions[i]->getType()=="free" && editions[i]->getRent() && editions[i]->getNameRent()=="admin")
           {
               string str = to_string(editions[i]->getId());
               ui->id->addItem(str.c_str());
           }
       }
   }
}


