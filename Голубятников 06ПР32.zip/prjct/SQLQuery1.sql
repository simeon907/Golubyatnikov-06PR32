create database editions

create table edition(
id tinyint primary key not null identity, 
kind nvarchar(20) not null, 
title nvarchar(30) not null, 
author nvarchar(30) not null, 
date_ date not null, 
pages int not null, 
rent bit not null, 
name_rent nvarchar(30) not null
)

create table paid_edition(
id tinyint primary key not null identity, 
kind nvarchar(20) not null, 
title nvarchar(30) not null, 
author nvarchar(30) not null, 
date_ date not null, 
pages int not null, 
rent bit not null, 
name_rent nvarchar(30) not null, 
price float not null
)
select * from edition
select * from paid_edition

insert into edition values('book', 'c', 'shyld', '2021-05-27', 1000, 0, '');
insert into paid_edition values('book', 'c++', 'shyld', '2021-05-27', 2000, 0, '', 50);