#include "edition.h"

Edition::Edition()
{
    this->kind="book";
    this->title="c++";
    this->author="shyld";
    this->date = Date();
    this->pages = 1000;
    this->rent=false;
    this->nameRent="";
}

Edition::Edition(string kind, string title, string author, Date date, int pages, bool rent, string nameRent, int id)
{
    if(!kind.empty() && !title.empty() && !author.empty() && pages >0)
    {
        this->kind=kind;
        this->title=title;
        this->author=author;
        this->date = date;
        this->pages = pages;
        this->rent=false;
        this->nameRent="";
        this->rent=rent;
        this->nameRent=nameRent;
        this->id = id;
    }
}

void Edition:: setKind(string kind)
{
    if(!kind.empty())
        this->kind = kind;
}

string Edition:: getKind()
{
    return kind;
}

void Edition:: setTitle(string title)
{
    if(!title.empty())
        this->title=title;
}

string Edition:: getTitle()
{
    return title;
}

void Edition:: setAuthor(string author)
{
    if(!author.empty())
        this->author=author;
}

string Edition:: getAuthor()
{
    return author;
}

void Edition:: setDate(Date date)
{
    this->date=date;
}

Date Edition:: getDate()
{
    return date;
}

void Edition:: setPages(int pages)
{
    if(pages>0)
        this->pages=pages;
}

int Edition:: getPages()
{
    return pages;
}

void Edition:: setRent(bool rent)
{
   this->rent = rent;
}

bool Edition:: getRent()
{
    return rent;
}

void Edition:: setNameRent(string nameRent)
{
    if(!nameRent.empty())
        this->nameRent=nameRent;
}

string Edition:: getNameRent()
{
    return nameRent;
}

string Edition::dateToString()
{
    return to_string(date.getYear()) +"."+ to_string(date.getMonth()) +"."+ to_string(date.getDay());
}

string Edition::getType()
{
    return "free";
}

void Edition::setId(int id)
{
    this->id=id;
}

int Edition::getId()
{
    return id;
}
