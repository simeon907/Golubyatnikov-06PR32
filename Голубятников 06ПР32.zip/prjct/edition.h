#ifndef EDITION_H
#define EDITION_H


#include <string>
#include "Date.h"
using namespace std;

class Edition
{
private:
    string kind;
    string title;
    string author;
    Date date;
    int pages;
    bool rent;
    string nameRent;
    int id = 0;

public:
    Edition();
    Edition(string kind, string title, string author, Date date, int pages, bool rent, string nameRent, int id);
    virtual ~Edition() {};

    void setKind(string kind);
    string getKind();
    void setTitle(string title);
    string getTitle();
    void setAuthor(string author);
    string getAuthor();
    void setDate(Date date);
    Date getDate();
    void setPages(int pages);
    int getPages();
    void setRent(bool rent);
    bool getRent();
    void setNameRent(string nameRent);
    string getNameRent();
    void setId(int id);
    int getId();
   // virtual float getPrice(){return 0;};

    string dateToString();
    virtual string getType();

};

#endif // EDITION_H
