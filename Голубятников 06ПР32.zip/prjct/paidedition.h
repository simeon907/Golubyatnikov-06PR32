#ifndef PAIDEDITION_H
#define PAIDEDITION_H

#include "edition.h"

class PaidEdition : public Edition
{
private:
    float price;
public:
    PaidEdition();
    PaidEdition(string kind, string title, string author, Date date, int pages, bool rent, string nameRent, int id, float price);
    virtual ~PaidEdition() {};

    void setPrice(float price);
    float getPrice();

    virtual string getType();
};

#endif // PAIDEDITION_H
