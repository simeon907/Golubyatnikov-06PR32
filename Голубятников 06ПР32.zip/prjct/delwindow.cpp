#include "delwindow.h"
#include "ui_delwindow.h"
#include <QDebug>
#include <QMessageBox>
delWindow::delWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::delWindow)
{
    ui->setupUi(this);
    ui->type->addItem("edition");
    ui->type->addItem("paid_edition");
    db = QSqlDatabase::addDatabase("QODBC");

   QString connectString = "Driver={SQL Server};";
   connectString.append("Server=SIMEON-DESKTOP;");
   connectString.append("Database=EDITIONS;");
   db.setDatabaseName(connectString);

   if(db.open())
       ui->statusbar->showMessage("Connect");
   else
       ui->statusbar->showMessage("error connect");
}

delWindow::~delWindow()
{
    delete ui;
}

void delWindow::on_delete_2_clicked()
{
    QSqlDatabase db = QSqlDatabase::addDatabase("QODBC");

    QString connectString = "Driver={SQL Server};";
    connectString.append("Server=SIMEON-DESKTOP;");
    connectString.append("Database=EDITIONS;");
    db.setDatabaseName(connectString);

    if(db.open())
    {
        ui->statusbar->showMessage("connect");
        QSqlQuery query;
        QString str = ui->type->itemText(ui->type->currentIndex());
        string id = ui->id->text().toStdString();
        string qe = "delete from edition where id ='"+id+"' and rent = 0";
        string qpe = "delete from paid_edition where id ='"+id+"' and rent = 0";
        if(str=="edition")
            query.exec(qe.c_str());
        else
            query.exec(qpe.c_str());
        ui->statusbar->showMessage("success");

    }
    else
    {
        ui->statusbar->showMessage("error connect");
    }
}

