#include "adminwindow.h"
#include "ui_adminwindow.h"
#include <QFile>
#include <QDebug>
#include <QMessageBox>

AdminWindow::AdminWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::AdminWindow)
{
    ui->setupUi(this);
    addwin = new addWindow();
    delwin = new delWindow();
    gea = new GetEditionAdm();
    re = new ReturnEdition();

    db = QSqlDatabase::addDatabase("QODBC");

    QString connectString = "Driver={SQL Server};";
    connectString.append("Server=SIMEON-DESKTOP;");
    connectString.append("Database=EDITIONS;");
    db.setDatabaseName(connectString);

    if(db.open())
    {
        ui->statusbar->showMessage("Connect");
        load();
        showListToTableWidget();

    }
    else
        ui->statusbar->showMessage("error connect");
}

AdminWindow::~AdminWindow()
{
    delete ui;
    db.close();
}

void AdminWindow::on_addButton_clicked()
{
    addwin->show();
}

void AdminWindow::load()
{
    QSqlQuery query;
    query.exec("SELECT * FROM EDITION");

    while (query.next())
    {
       string kind = query.value(1).toString().toStdString();
       string title = query.value(2).toString().toStdString();
       string author = query.value(3).toString().toStdString();
       QString date = query.value(4).toString();
       QStringList datelist = date.split('-');
       Date d(datelist.at(0).toInt(), datelist.at(1).toInt(), datelist.at(2).toInt());
       int pages = query.value(5).toInt();
       bool rent = query.value(6).toBool();
       string nameRent = query.value(7).toString().toStdString();
       int id = query.value(0).toInt();
       editions.push_back(new Edition(kind, title, author, d, pages, rent, nameRent, id));
    }

    query.exec("SELECT * FROM paid_edition");

    while (query.next())
    {
       string kind = query.value(1).toString().toStdString();
       string title = query.value(2).toString().toStdString();
       string author = query.value(3).toString().toStdString();
       QString date = query.value(4).toString();
       QStringList datelist = date.split('-');
       Date d(datelist.at(0).toInt(), datelist.at(1).toInt(), datelist.at(2).toInt());
       int pages = query.value(5).toInt();
       bool rent = query.value(6).toBool();
       string nameRent = query.value(7).toString().toStdString();
       float price = query.value(8).toFloat();
       int id = query.value(0).toInt();
       editions.push_back(new PaidEdition(kind, title, author, d, pages, rent, nameRent, id, price));
    }
}

void AdminWindow::showListToTableWidget()
{
    if(editions.size()==ui->tableWidget->rowCount())
        ui->tableWidget->setRowCount(editions.size()+1);
    else
         ui->tableWidget->setRowCount(editions.size());
    for(int i = 0 ;i<editions.size();i++)
    {
        QTableWidgetItem *elementId =  new QTableWidgetItem();
        QTableWidgetItem *elementTy =  new QTableWidgetItem();
        QTableWidgetItem *elementK =  new QTableWidgetItem();
        QTableWidgetItem *elementT =  new QTableWidgetItem();
        QTableWidgetItem *elementA =  new QTableWidgetItem();
        QTableWidgetItem *elementD =  new QTableWidgetItem();
        QTableWidgetItem *elementP =  new QTableWidgetItem();
        QTableWidgetItem *elementR =  new QTableWidgetItem();
        QTableWidgetItem *elementNR =  new QTableWidgetItem();

        elementId->setText(QString().setNum(editions[i]->getId()));
        elementTy->setText(QString().asprintf("%s",editions[i]->getType().c_str()));
        elementK->setText(QString().asprintf("%s",editions[i]->getKind().c_str()));
        elementT->setText(QString().asprintf("%s",editions[i]->getTitle().c_str()));
        elementA->setText(QString().asprintf("%s",editions[i]->getAuthor().c_str()));
        elementD->setText(QString().asprintf("%s",editions[i]->dateToString().c_str()));
        elementP->setText(QString().setNum(editions[i]->getPages()));
        elementR->setText(QString().setNum(editions[i]->getRent()));
        elementNR->setText(QString().asprintf("%s",editions[i]->getNameRent().c_str()));

        ui->tableWidget->setItem(i, 0, elementId);
        ui->tableWidget->setItem(i, 1, elementTy);
        ui->tableWidget->setItem(i, 2, elementK);
        ui->tableWidget->setItem(i, 3, elementT);
        ui->tableWidget->setItem(i, 4, elementA);
        ui->tableWidget->setItem(i, 5, elementD);
        ui->tableWidget->setItem(i, 6, elementP);
        ui->tableWidget->setItem(i, 7, elementR);
        ui->tableWidget->setItem(i, 8, elementNR);
    }
}


void AdminWindow::on_delButton_clicked()
{
    delwin->show();
}


void AdminWindow::on_update_clicked()
{
    ui->statusbar->showMessage("updating...");
    db.close();
    db = QSqlDatabase::addDatabase("QODBC");
   QString connectString = "Driver={SQL Server};";
   connectString.append("Server=SIMEON-DESKTOP;");
   connectString.append("Database=EDITIONS;");
   db.setDatabaseName(connectString);

   if(db.open())
   {
       ui->statusbar->showMessage("updated");
       editions.clear();
       load();
       showListToTableWidget();
   }
}



void AdminWindow::on_get_clicked()
{
    gea->show();
}


void AdminWindow::on_returnEd_clicked()
{
    re->show();
}

