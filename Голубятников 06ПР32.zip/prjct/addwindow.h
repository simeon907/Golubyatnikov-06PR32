#ifndef ADDWINDOW_H
#define ADDWINDOW_H

#include <QMainWindow>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlDatabase>
#include <string>
#include <QVector>
#include "edition.h"
#include "paidedition.h"

namespace Ui {
class addWindow;
}

class addWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit addWindow(QWidget *parent = nullptr);
    ~addWindow();

private slots:
    void on_pushButton_clicked();

//signals:
//    void sendData(QString text);

private:
    Ui::addWindow *ui;
    QVector<Edition*> editions;
    QSqlDatabase db;
};

#endif // ADDWINDOW_H
