#include "paidedition.h"

PaidEdition::PaidEdition():Edition()
{
    price = 1;
}

PaidEdition::PaidEdition(string kind, string title, string author, Date date, int pages, bool rent, string nameRent, int id, float price)
    :Edition(kind, title, author, date, pages, rent, nameRent, id)
{
    if(price>0)
        this->price = price;
}

void PaidEdition::setPrice(float price)
{
    this->price=price;
}

float PaidEdition::getPrice()
{
    return price;
}

string PaidEdition::getType()
{
    return "paid";
}
