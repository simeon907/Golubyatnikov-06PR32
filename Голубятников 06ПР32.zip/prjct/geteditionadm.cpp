#include "geteditionadm.h"
#include "ui_geteditionadm.h"
#include <QDebug>
#include <QMessageBox>


GetEditionAdm::GetEditionAdm(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::GetEditionAdm)
{
    ui->setupUi(this);
    ui->type->addItem("edition");
    ui->type->addItem("paid_edition");
    ui->lprice->hide();
    ui->pricedigit->hide();
    ui->spinPrice->hide();

    db = QSqlDatabase::addDatabase("QODBC");

    QString connectString = "Driver={SQL Server};";
    connectString.append("Server=SIMEON-DESKTOP;");
    connectString.append("Database=EDITIONS;");
    db.setDatabaseName(connectString);

    if(db.open())
    {
        ui->statusbar->showMessage("Connect");
        load();
        for(int i = 0;i<editions.size();i++)
        {
            if(editions[i]->getType()=="free" && !editions[i]->getRent())
            {
                string str = to_string(editions[i]->getId());
                ui->id->addItem(str.c_str());
            }
        }
    }
    else
        ui->statusbar->showMessage("error connect");
}

GetEditionAdm::~GetEditionAdm()
{
    delete ui;
    db.close();
}

void GetEditionAdm::on_get_clicked()
{
    QString selectedId = ui->id->itemText(ui->id->currentIndex());

    QSqlQuery query;
    QString type = ui->type->itemText(ui->type->currentIndex());
    qDebug()<<selectedId<<"|"<<type;
    float selectedPrice = ui->spinPrice->text().toFloat();
    float price = ui->pricedigit->text().toFloat();
    if(selectedPrice>= price)
    {
        QString q = "update "+type+" set rent = 1, name_rent = 'admin' where id ="+selectedId;
        query.exec("select * from "+type+" where id = "+selectedId);
        query.first();
        qDebug()<<q;
        qDebug()<<query.value(6).toBool();
        if(!query.value(6).toBool())
            query.exec(q);
        else
            QMessageBox::warning(this, "Error", "this edition has been rented");
        ui->statusbar->showMessage("updated");
    }
    else
        QMessageBox::warning(this, "Error", "you don't have enough money");
}

void GetEditionAdm::load()
{
    QSqlQuery query;
    query.exec("SELECT * FROM EDITION");

    while (query.next())
    {
       string kind = query.value(1).toString().toStdString();
       string title = query.value(2).toString().toStdString();
       string author = query.value(3).toString().toStdString();
       QString date = query.value(4).toString();
       QStringList datelist = date.split('-');
       Date d(datelist.at(0).toInt(), datelist.at(1).toInt(), datelist.at(2).toInt());
       int pages = query.value(5).toInt();
       bool rent = query.value(6).toBool();
       string nameRent = query.value(7).toString().toStdString();
       int id = query.value(0).toInt();
       editions.push_back(new Edition(kind, title, author, d, pages, rent, nameRent, id));
    }

    query.exec("SELECT * FROM paid_edition");

    while (query.next())
    {
       string kind = query.value(1).toString().toStdString();
       string title = query.value(2).toString().toStdString();
       string author = query.value(3).toString().toStdString();
       QString date = query.value(4).toString();
       QStringList datelist = date.split('-');
       Date d(datelist.at(0).toInt(), datelist.at(1).toInt(), datelist.at(2).toInt());
       int pages = query.value(5).toInt();
       bool rent = query.value(6).toBool();
       string nameRent = query.value(7).toString().toStdString();
       float price = query.value(8).toFloat();
       int id = query.value(0).toInt();
       editions.push_back(new PaidEdition(kind, title, author, d, pages, rent, nameRent, id, price));
    }
}


void GetEditionAdm::on_type_activated(const QString &arg1)
{
    ui->id->clear();
    editions.clear();
    QString type = ui->type->itemText(ui->type->currentIndex());
    load();
    for(int i = 0;i<editions.size();i++)
    {
        if(type == "edition" && editions[i]->getType()=="free" && !editions[i]->getRent())
        {
            string str = to_string(editions[i]->getId());
            ui->id->addItem(str.c_str());
            ui->lprice->hide();
            ui->pricedigit->hide();
        }
        else if(type =="paid_edition" && editions[i]->getType()=="paid" && !editions[i]->getRent())
        {
            string str = to_string(editions[i]->getId());
            ui->id->addItem(str.c_str());
        }
    }
    if(type == "paid_edition")
    {
        int id = ui->id->itemText(ui->id->currentIndex()).toInt();
        qDebug()<<id;
        ui->lprice->show();
        ui->pricedigit->show();
        ui->spinPrice->show();
        for(int i = 0;i<editions.size();i++)
        {
            if(editions[i]->getId()==id)
            {
                string p = to_string(((PaidEdition*)editions[i])->getPrice());
                qDebug()<<p.c_str();
                ui->pricedigit->setText(p.c_str());
            }
        }


    }
}

//void GetEditionAdm::getData(QString text)
//{
//    QStringList list=text.split("=");
//    editions.push_back(list.at(0))
//}


void GetEditionAdm::on_pushButton_clicked()
{
    ui->statusbar->showMessage("updating...");
    ui->lprice->hide();
    ui->pricedigit->hide();
    ui->spinPrice->hide();

    db.close();
    db = QSqlDatabase::addDatabase("QODBC");
   QString connectString = "Driver={SQL Server};";
   connectString.append("Server=SIMEON-DESKTOP;");
   connectString.append("Database=EDITIONS;");
   db.setDatabaseName(connectString);

   if(db.open())
   {
       ui->statusbar->showMessage("updated");
       editions.clear();
       load();
       ui->id->clear();
       ui->type->clear();
       ui->type->addItem("edition");
       ui->type->addItem("paid_edition");
       for(int i = 0;i<editions.size();i++)
       {
           if(editions[i]->getType()=="free" && !editions[i]->getRent())
           {
               string str = to_string(editions[i]->getId());
               ui->id->addItem(str.c_str());
           }
       }
   }
}


void GetEditionAdm::on_id_activated(const QString &arg1)
{
    QString type = ui->type->itemText(ui->type->currentIndex());
    if(type == "paid_edition")
    {
        int id = ui->id->itemText(ui->id->currentIndex()).toInt();
        qDebug()<<"id"<<id;
        ui->lprice->show();
        ui->pricedigit->show();
        for(int i = 0;i<editions.size();i++)
        {
            if(editions[i]->getId()==id)
            {
                string p = to_string(((PaidEdition*)editions[i])->getPrice());
                ui->pricedigit->setText(p.c_str());
            }
        }
    }
}

